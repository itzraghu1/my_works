<?php
require 'vendor/autoload.php';

use Salaros\Vtiger\VTWSCLib\WSClient;

$client = new WSClient('http://resolve-legal.borugroup.com', 'admin', 'hGahP2gq1EyMxjkr');


// Look for Ivan Petrov among Leads
$ivanPetrovId = $client->entities->getNumericID('Leads', [
	'firstname'         => 'Ivan',
	'lastname'          => 'Petrov',
]);

// Add his record if it doesn't exist
if (intval($ivanPetrovId) < 1) {
	$ivanPetrov = $client->entities->createOne('Leads', [
		'salutationtype'    => 'Mr.',
		'firstname'         => 'Ivan',
		'lastname'          => 'Petrov',
		'phone'             => "+7 495 4482237",
		'fax'               => "+7 495 3895096",
		'company'           => "ACME Ltd",
		'email'             => "roga-kopyta.ru",
		'leadsource'        => "Trade Show",
		'website'           => "roga-kopyta.ru",
		'leadstatus'        => "Cold",
	]);
	echo "<pre>";
	print_r($ivanPetrov);
} else {
	echo('Ivan Petrov\'s record already exists!' . PHP_EOL);
}


?>