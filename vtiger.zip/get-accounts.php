
<?php
require 'vendor/autoload.php';

use Salaros\Vtiger\VTWSCLib\WSClient;

$client = new WSClient('http://resolve-legal.borugroup.com', 'admin', 'hGahP2gq1EyMxjkr');
echo "<pre>";
print_r($client->modules->getOne('Accounts'));

?>
