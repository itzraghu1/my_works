<?php 
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



function sendMail($recipient_email,$recipient_name,$subject,$body){
    try {
        $mail = new PHPMailer(true);    
        $mail->SMTPDebug = 2;                                 
        $mail->isSMTP();                                      
        $mail->Host = 'smtp.gmail.com';  
        $mail->SMTPAuth = true;                               
        $mail->Username = 'logimetrix@gmail.com';                 
        $mail->Password = 'logimetriX@!@#$';                           
        $mail->SMTPSecure = 'tls';                            
        $mail->Port = 587;                                   
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $mail->setFrom('cardicon2020@gmail.com', 'Cardicon2020');
        $mail->addAddress($recipient_email, $recipient_name);


        $mail->isHTML(true);                                  
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
       return 'Message could not be sent. Mailer Error: '. $mail->ErrorInfo;
   }
}

sendMail('raghvendra@logimetrix.co.in','Raghvendra','TEsting',"Test body");

?>