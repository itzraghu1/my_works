<?php
$con = mysqli_connect("localhost","crm","crm@54321","crm");
if (mysqli_connect_errno()) {
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	exit();
}
?>