<?php
require 'vendor/autoload.php';

use Salaros\Vtiger\VTWSCLib\WSClient;

$client = new WSClient('http://resolve-legal.borugroup.com', 'admin', 'hGahP2gq1EyMxjkr');

$ivanPetrov = $client->entities->createOne('Accounts', [
	'accountname'    => 'Mr.Ivan',
	'account_no'         => '123456',
	'phone'             => "+7 495 4482237",
	'bill_city'             => "Lucknow",
]);
echo "<pre>";
print_r($ivanPetrov);


?>