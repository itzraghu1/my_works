<?php
require 'db.php';
require 'vendor/autoload.php';
use Salaros\Vtiger\VTWSCLib\WSClient;


$client = new WSClient('http://resolve-legal.borugroup.com', 'admin', 'hGahP2gq1EyMxjkr');

$sql = "SELECT * FROM accounts WHERE created_at LIKE '%".date('Y-m-d')."%'";
$result = mysqli_query($con, $sql);
while ($row =  mysqli_fetch_assoc($result)) {
	// echo "<pre>";
	// print_r($row);
	
	$data = $client->entities->createOne('Accounts', [
		'accountname'       => $row['name'],
		'account_no'         => $row['customer_number'],
		'phone'             => $row['mobile'],
		'bill_street'             => $row['address'],
		// 'assigned_user_id'  => $row['sales_agent'],
		// 'cf_641'             => $row['call_back_date'],
		'cf_763'             => $row['account_status'],
		'cf_777'             => $row['lead_source'],
		'cf_834'             => $row['call_transfer_time'],
		'cf_836'             => $row['enquiry_type'],
		'cf_839'             => $row['date_of_injury_aware'],
		'cf_840'             => $row['potential_defendant'],
		'cf_844'             => $row['home_telephone_number'],
		'cf_845'             => $row['mobile_telephone_number'],
		'cf_846'             => $row['email'],
		'cf_848'             => $row['date_of_birth'],
		'cf_849'             => $row['panel_refrence'],
		'cf_850'             => $row['type_of_lead'],
		'cf_853'             => $row['date_lead_recieved'],
		'cf_854'             => $row['lead_quality'],
		'cf_855'             => $row['facebook_injury_date'],
		'cf_837'             => date('d-m-Y',strtotime($row['date_of_injury'])),
		'cf_838'             => $row['injury_type'],
		'cf_842'             => $row['first_name'],
		'cf_843'             => $row['last_name'],
	]);
	// echo "<pre>";
	// print_r($data);

}

?>