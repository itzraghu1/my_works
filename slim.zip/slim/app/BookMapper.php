<?php
namespace App;

class BookMapper extends Mapper
{
	public function getBooks() {
		$sql = "SELECT *
		from books" ;
		$stmt = $this->db->query($sql);
		$results = $stmt->fetch();
		return $results;
	}
    /**
     * Get one ticket by its ID
     *
     * @param int $ticket_id The ID of the ticket
     * @return TicketEntity  The ticket
     */
    public function getBookById($book_id) {
    	$sql = 'SELECT 
    	from books 
    	where id = ?';
    	$stmt = $this->db->prepare($sql);
    	$result = $stmt->execute([$book_id]);
    	if($result) {
            $result = $stmt->fetch();
        }
    }
    public function save(TicketEntity $ticket) {
    	$sql = "insert into tickets
    	(title, description, component_id) values
    	(:title, :description, 
    		(select id from components where component = :component))";
    		$stmt = $this->db->prepare($sql);
    		$result = $stmt->execute([
    			"title" => $ticket->getTitle(),
    			"description" => $ticket->getDescription(),
    			"component" => $ticket->getComponent(),
    		]);
    		if(!$result) {
    			throw new Exception("could not save record");
    		}
    	}
    }