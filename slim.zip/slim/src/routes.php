<?php

use Slim\Http\Request;
use Slim\Http\Response;
use App\BookMapper;
// Routes


$app->get('/books', function (Request $request, Response $response, array $args) {
	$mapper = new BookMapper($this->db);
	$books = $mapper->getBooks();
	$response->getBody()->write(var_export($books, true));
	return $response;
});

$app->get('/book/{id}', function (Request $request, Response $response, $args) {
	$book_id = (int)$args['id'];
	$mapper = new BookMapper($this->db);
	$book = $mapper->getbookById($book_id);
	$response->getBody()->write(var_export($ticket, true));
	return $response;
});


