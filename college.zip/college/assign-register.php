<?php 
date_default_timezone_set('Asia/Kolkata');

include "db.php";
$response = array();
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$request = json_decode(file_get_contents('php://input'));
	if(!isset($request->register_id) || $request->register_id == ""){
		$response['flag'] = false;
		$response['message'] = "Register Missing";
	}else if(!isset($request->hod_id) || $request->hod_id == ""){
		$response['flag'] = false;
		$response['message'] = "HOD Missing";
	}else{
		$sql = "SELECT * FROM register_hod_assoc WHERE register_id = ".$request->register_id." AND hod_id =".$request->hod_id;
		if ($result = mysqli_query($con,$sql)){
			if(mysqli_num_rows($result)){
				$response['flag'] = false;
				$response['message'] = "Already Mapped";
			}else{
				$check_sql = "SELECT * FROM register_hod_assoc WHERE register_id = ".$request->register_id;
				if ($result = mysqli_query($con,$check_sql)){

					if(mysqli_num_rows($result)){

						$register_mapping = mysqli_fetch_assoc($result);
						if($register_mapping['hod_id'] != $request->hod_id){
							$date = date('Y-m-d H:i:s');
							$update_sql = "UPDATE `register_hod_assoc` SET hod_id =  $request->hod_id WHERE $request->register_id";
							if ($result = mysqli_query($con,$update_sql)){
								$response['flag'] = true;
								$response['message'] = "Assignment Updated Successfully";
							}else{
								$response['flag'] = false;
								$response['message'] = "Server Issue";
							}

							
						}
					}else{

						$date = date('Y-m-d H:i:s');
						$insert_sql = "INSERT INTO `register_hod_assoc`(`id`, `register_id`, `hod_id`, `created_at`) VALUES (NULL,$request->register_id,$request->hod_id,'$date')";
						if ($result = mysqli_query($con,$insert_sql)){
							$response['flag'] = true;
							$response['message'] = "Assigned Successfully";
						}else{
							$response['flag'] = false;
							$response['message'] = "Server Issue";
						}

					}
					
				}else{
					$response['flag'] = false;
					$response['message'] = "Server Issue";

				}
				

			}
		}else{
			$response['flag'] = false;
			$response['message'] = "Server Issue";
		}
		
	}
}else{
	$response['flag'] = false;
	$response['message'] = "Method Not Allowed";
}

echo json_encode($response);



?>