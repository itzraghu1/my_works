<?php 
date_default_timezone_set('Asia/Kolkata');

include "db.php";
$response = array();
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$request = json_decode(file_get_contents('php://input'));
	if(!isset($request->department_id) || $request->department_id == ""){
		$response['flag'] = false;
		$response['message'] = "Department Missing";
	}else if(!isset($request->hod_id) || $request->hod_id == ""){
		$response['flag'] = false;
		$response['message'] = "HOD Missing";
	}else{
		$sql = "SELECT * FROM department_hod_assoc WHERE department_id = ".$request->department_id." AND hod_id =".$request->hod_id;
		if ($result = mysqli_query($con,$sql)){
			if(mysqli_num_rows($result)){
				$response['flag'] = false;
				$response['message'] = "Already Mapped";
			}else{

				$date = date('Y-m-d H:i:s');
				$sql = "INSERT INTO `department_hod_assoc`(`id`, `department_id`, `hod_id`, `created_at`) VALUES (NULL,$request->department_id,$request->hod_id,'$date')";
				if ($result = mysqli_query($con,$sql)){
					$response['flag'] = true;
					$response['message'] = "Assigned Successfully";
				}else{
					$response['flag'] = false;
					$response['message'] = "Server Issue";
				}

			}
		}else{
			$response['flag'] = false;
			$response['message'] = "Server Issue";
		}
		
	}
}else{
	$response['flag'] = false;
	$response['message'] = "Method Not Allowed";
}

echo json_encode($response);



?>