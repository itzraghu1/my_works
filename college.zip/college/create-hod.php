<?php 
date_default_timezone_set('Asia/Kolkata');

include "db.php";
$response = array();
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$request = json_decode(file_get_contents('php://input'));
	if(!isset($request->name) || $request->name == ""){
		$response['flag'] = false;
		$response['message'] = "Name Missing";
	}else{
		$sql = "SELECT * FROM users WHERE role = 3 AND name = '".$request->name."'";
		if ($result = mysqli_query($con,$sql)){
			if(mysqli_num_rows($result)){
				$response['flag'] = false;
				$response['message'] = "Already Exist";
			}else{

				$date = date('Y-m-d H:i:s');
				$sql = "INSERT INTO `users`(`id`, `name`,`role`,`created_at`) VALUES (NULL,'$request->name',3,'$date')";
				if ($result = mysqli_query($con,$sql)){
					$response['flag'] = true;
					$response['message'] = "Created Successfully";
				}else{
					$response['flag'] = false;
					$response['message'] = "Server Issue";
				}

			}
		}else{
			$response['flag'] = false;
			$response['message'] = "Server Issue";
		}
		
	}
}else{
	$response['flag'] = false;
	$response['message'] = "Method Not Allowed";
}

echo json_encode($response);



?>