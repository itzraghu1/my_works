<?php 
include "db.php";
$response = array();
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$request = json_decode(file_get_contents('php://input'));
	if(!isset($request->username) || $request->username == ""){
		$response['flag'] = false;
		$response['message'] = "Username Missing";
	}else if(!isset($request->password) || $request->password == ""){
		$response['flag'] = false;
		$response['message'] = "Password Missing";
	}else{
		$sql = "SELECT * FROM users WHERE username = '".$request->username."' AND password ='".$request->password."'";
		if ($result = mysqli_query($con,$sql)){
			if(mysqli_num_rows($result)){
				$user = mysqli_fetch_assoc($result);
				$response['flag'] = false;
				$response['message'] = "logged in successfully";
				$response['user'] = $user;

			}else{
				$response['flag'] = false;
				$response['message'] = "Invalid Username or Password";
			}
		}else{
			$response['flag'] = false;
			$response['message'] = "Server Issue";
		}
	}
}else{
	$response['flag'] = false;
	$response['message'] = "Method Not Allowed";
}

echo json_encode($response);



?>