
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateModulesTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('modules', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->string('module', 191);
            $table->string('link', 191);
            $table->string('icon', 255);
            $table->integer('is_active')->default('1');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('modules');
			}
		}
		