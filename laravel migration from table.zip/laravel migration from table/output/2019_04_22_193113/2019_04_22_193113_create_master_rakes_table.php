
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateMasterrakesTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('master_rakes', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->string('name', 191);
            $table->integer('session_id');
            $table->integer('product_company_id');
            $table->string('loading_time', 191);
            $table->string('unloading_time', 191);
            $table->date('date');
            $table->integer('is_active')->default('1');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('master_rakes');
			}
		}
		