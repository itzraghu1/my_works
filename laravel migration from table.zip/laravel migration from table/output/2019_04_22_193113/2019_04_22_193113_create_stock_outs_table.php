
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateStockoutsTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('stock_outs', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->integer('stock_token_id');
            $table->integer('dealer_id');
            $table->integer('warehouse_id');
            $table->integer('created_by');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('stock_outs');
			}
		}
		