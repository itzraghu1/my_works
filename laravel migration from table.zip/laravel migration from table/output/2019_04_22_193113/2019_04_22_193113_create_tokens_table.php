
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateTokensTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('tokens', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->integer('master_rake_id');
            $table->integer('company_id');
            $table->integer('dealer_id');
            $table->date('date_of_generation');
            $table->integer('warehouse_id');
            $table->integer('rate');
            $table->integer('product_company_id');
            $table->integer('product_id');
            $table->integer('quantity');
            $table->integer('unit_id');
            $table->integer('account_id');
            $table->integer('transporter_id');
            $table->integer('warehouse_keeper_id');
            $table->string('truck_number', 191);
            $table->mediumtext('description');
            $table->integer('is_active')->default('1');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('tokens');
			}
		}
		