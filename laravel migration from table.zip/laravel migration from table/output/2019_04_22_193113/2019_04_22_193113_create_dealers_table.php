
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateDealersTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('dealers', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->string('unique_id', 191);
            $table->string('name', 191);
            $table->string('phone', 255);
            $table->text('address1');
            $table->text('address2');
            $table->string('district', 255);
            $table->string('pin_code', 255);
            $table->string('owner_name', 255);
            $table->string('mobile_number', 255);
            $table->string('email', 255);
            $table->string('ifms_code', 255);
            $table->string('gst_number', 255);
            $table->integer('is_active')->default('1');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('dealers');
			}
		}
		