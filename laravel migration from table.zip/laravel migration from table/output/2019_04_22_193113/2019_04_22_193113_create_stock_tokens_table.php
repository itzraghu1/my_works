
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateStocktokensTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('stock_tokens', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->integer('company_id');
            $table->integer('dealer_id');
            $table->date('date_of_generation');
            $table->integer('warehouse_id');
            $table->integer('rate');
            $table->integer('product_id');
            $table->integer('quantity');
            $table->integer('unit_id');
            $table->integer('account_id');
            $table->integer('transporter_id');
            $table->integer('warehouse_keeper_id');
            $table->string('truck_number', 191);
            $table->mediumtext('description');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('stock_tokens');
			}
		}
		