
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateSubmodulesTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('sub_modules', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->integer('module_id');
            $table->string('sub_module', 191);
            $table->string('link', 191);
            $table->integer('is_active')->default('1');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('sub_modules');
			}
		}
		