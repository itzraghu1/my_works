
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateUsersTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('users', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->string('name', 191);
            $table->string('email', 191);
            $table->string('password', 191);
            $table->string('plain_password', 191);
            $table->integer('role_id');
            $table->string('api_token', 80);
            $table->integer('is_active')->default('1');
            $table->string('remember_token', 100);
            $table->timestamps();
            $table->unique(["email"]);
            $table->unique(["api_token"]);
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('users');
			}
		}
		