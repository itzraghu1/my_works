
	<?php
	use Illuminate\Support\Facades\Schema;
	use Illuminate\Database\Schema\Blueprint;
	use Illuminate\Database\Migrations\Migration;
	class CreateRakesTable extends Migration
	{
		/**
     * Run the migrations.
     *
     * @return void
     */
		public function up()
		{
			Schema::create('rakes', function (Blueprint $table) {
				    $table->increments('id', 20);
            $table->string('name', 255);
            $table->integer('master_rake_id');
            $table->string('rake_no', 191);
            $table->string('quantity', 191);
            $table->integer('product_id');
            $table->integer('is_active')->default('1');
            $table->timestamps();
				});
			}
			/**
     * Reverse the migrations.
     *
     * @return void
     */
			public function down()
			{
				Schema::dropIfExists('rakes');
			}
		}
		