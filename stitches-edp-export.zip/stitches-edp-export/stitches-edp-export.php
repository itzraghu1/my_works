<?php
/**
  *Plugin Name: Bulk EDP Export for ShopWorks Onsite7
  *Plugin URI:
  *Description: Converts order form submissions via Gravity Form entries to bulk EDP format for attachment to an outgoing email.
  *Has both scheduled and manual excution options. Scheduling times cannot be done through the plugin currently.
  *Version: 0.1.5
  *Author: Nathan Dang @ Credo Technology Group
  *Author URI:
  *License:
  */
/* 
 * MISSING: How to interact with other files which make up the plugin. Proper set up for a button which executes the stitches_orderbot() function.
*/
// Create page for user to interact with for manual runs
require 'export-function.php';
add_action('admin_menu', 'run_bulk_edp');
add_action('my_daily_event', 'stitches_orderbot');
wp_schedule_event(time(), 'daily', 'my_daily_event');

// WordPress function to create the menu item.
function run_bulk_edp() {
// WordPress function to add custom css.
  add_action( 'admin_enqueue_scripts', create_function( '',
    "wp_enqueue_style( 'stitches-edp-wp-admin', '" . plugins_url().'/stitches-edp-export' . "/css/custom.css');")
);
  add_action( 'admin_enqueue_scripts', create_function( '',
    "wp_enqueue_script( 'stitches-edp-wp-admin', '" . plugins_url().'/stitches-edp-export' . "/js/custom.js');")
);


  add_menu_page('Manual Bulk EDP Export', 'EDP Export', 'manage_options', 'edp-export', 'export_edp_init');
  add_submenu_page( 'edp-export', 'Log', 'View Log', 'manage_options', 'edp-export-log', 'edp_export_log');

}
/******** Function to create a page where manual backups can be run. ********
	* Basic page needs to show a completion notice after stitches_orderbot() function runs
  ********/
  function export_edp_init() {
    if (isset($_GET['type']) && $_GET['type'] == 'cron' ) {
      stitches_orderbot();
    }
    if (isset($_POST['export_btn'])) {
      stitches_orderbot();
    }
    $btnType = array('primary','large');
    ?>
    <h2>Bulk EDP Export</h2>
    <p>Let the Stitches Orderbot run a manual bulk export for you.</p>
    <form  method="post">
      <?php submit_button('Export Orders', $btnType, 'export_btn'); ?>
    </form>    
    <?php } ?>
    <?php
    function edp_export_log(){ 
     global $wpdb;
     $cron_log_table = $wpdb->prefix . "cron_log";
     $sqlLog =  $wpdb->prepare("SELECT * FROM `$cron_log_table` ORDER BY `job_id` DESC ");
     $sqlLogResult = $wpdb->get_results($sqlLog);

     ?>

     <div class="container">
      <div class="row">
        <div class="col-m-12">
         <table id="order-view">
          <thead>
            <tr>
              <th>Date</th>
              <th>Order Processed</th>
            </tr>
          </thead>
          <tbody>
           <?php foreach ($sqlLogResult as $value) { ?>
           <tr>
            <td><?php echo $value->datetime_run ?></td>
            <td><?php echo $value->num_orders ?></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php 
} ?>
