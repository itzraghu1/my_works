<?php include "export-function.php" ?>
<?php/******** Cron Job Functions ********	* Call WordPress functions to run automatic and manual CRON jobs.	* MISSING: Still need to add manual cron job functions.********/// Set up Cron Job Interface.
add_action('my_daily_event', 'stitches_orderbot');
//Trigger CRON
public static function activate() {
	wp_schedule_event(time(), 'daily', 'my_daily_event');
}
	//End CRON
public static function deactivate() 
{    
	wp_clear_scheduled_hook('my_daily_event');
	}// All hail Stitches Orderbot
	?>
	<!--PSUDO-CODECRON Run time trigger or Manual trigger ->check time last run ->set variables for last time ran and current trigger time for use in the MySQL query ->for previous time ran variable should be time +1 second ->if scheduled and morning add morning to file name else if scheduled and afternoon add afternoon to file name else if manaual add manual to file name ->execute MySQL query ->if no orders and scheduled send email with message "No orders were placed between X and Y date times" and no attachment, log trigger time, and end execution ->if no orders and manual give message no orders, log trigger time, and end execution ->if query finds order(s) run php code to create the EDP .txt file ->if manual email file with attachment then give message file was sent else email file with attachment ->log trigger time on server ->end execution |STOP!|-->