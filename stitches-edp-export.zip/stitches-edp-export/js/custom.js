function closePopup() {
	document.getElementById("myModal").style.display="none";
}	
