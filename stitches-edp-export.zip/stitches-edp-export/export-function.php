<?php
ob_start();
require('fpdf/fpdf.php');
    /**
      *Descrpition: Primary function to be run by cron jobs and manual activation.
      *The function establishes mail functions first. Then it establishes a 
      *connection to the server to run several queries. These queries are to get 
      *the last time this log was run to determin how far back the query should
      *check in hours, find out how many orders there are in that timeframe, and 
      *then gather all table rows which match those orders.
      *The function thens acts based on if there are orders or not. If there are 
      *none then it logs the cron job on the server and TBD before ending its
      *connection. While if there are orders it runs through a loop until all 
      *orders have been written to a single document. It then emails that document 
      *to Stitches Clothing Co and logs the run. before terminating the connection.
      *This function will account for both Chron jobs and manual runs.
    **/
    function success_popup($status,$numOrders){
        echo '
        <div id="myModal">
        <div  class="modal">
        <div class="modal-content">
        <div class="modal-header">
        <span class="close" onclick="closePopup()">&times;</span>
        <h2>EDP Export</h2>
        </div>
        <div class="modal-body">
        <p>Order processing status: '.$status.' </p>
        <p>Total Order processed: '.$numOrders.'</p>
        </div>
        </div>
        </div>
        <div class="mbopcity"></div>
        </div>
        ';
    }
    
    function stitches_orderbot() {
        global $wpdb;
    /******** Mail Functions ********
        * Establish mail functions to be used to send the compiled EDP text file.
    ********/
    // Mail error logger
    add_action('wp_mail_failed', 'log_mailer_errors', 10, 1);
    function log_mailer_errors() {
      $fn = ABSPATH . '/mail.log'; // say you've got a mail.log file in your server root
      $fp = fopen($fn, 'a');
      fputs($fp, "Mailer Error: " . $mailer->ErrorInfo ."\n");
      fclose($fp);
  }
  
    /**** Function for sending mail which calls wp_mail() function in WordPress ****
      * $qOrd should use $numOrders, $dtRun should use $dtRun, $dtLast should 
      * use $lastDt, and attachement should use the generated PDF.
    ****/
    function send_mail($qOrd, $dtRun, $dtLast, $dA, $attachements) {
        $to = 'Info SCC <info@stitchesclothingco.com>';     // Receiver
        $subject = $qOrd . ' Web Portal Orders made between ';      // Subject Line - !!!NOT COMPLETE!!! Need to add dates orders were made
        $body = 'Greetings Stitches Clothing Co.,' . "\r" . 'You have recieved ' . $qOrd . ' orders from the web portal since the last batch was sent.' . "\r" . 'Have a nice day' . "\r" . 'Stitches Orderbot';    // Body content
        $header = array('Content-Type: text/html; charset=UTF-8', 'From: Stitches Orderbot - Do not reply');    // Header info
        wp_mail($to, $subject, $body, $header, $attachments);   // Generates and sends the actual mail.
    }
    /******** End Mail Functions ********/
    
    /******** Time Determination ********
        * Used to determin the current run time as well as running checks against 
        * the last run time from a cron log table. These values will be used for 
        * gathering information from between the current run and the last run. As 
        * well as logging the current run in a dedicated MySQL table for logging 
        * cron jobs. This section also generates informtion to be used in emails.
    ********/
    // Set current time for the time to be logged for this particular Cron job
    // $runDt1 = current_time('mysql');
    $runDt1 = date('Y-m-d H:i:s');
    $runDt = new DateTime($runDt1);
    $cron_log_table = $wpdb->prefix . "cron_log";
    
    // Get the last cron datetime
    $true = 1;
    $sqlDt = $wpdb->prepare("SELECT `datetime_run` FROM `$cron_log_table` WHERE `run_complete` = %d ORDER BY `job_id` DESC LIMIT 1",$true);
    $lastDt = $wpdb->get_var($sqlDt);
    $lastDt = new DateTime($lastDt);
    
    if(is_null($lastDt)){
        $lastDt = $runDt;
    }
    
    /* Determin what is being run based on the current time and establish between 
     * what times the queries should check. 
     *
     * MISSING: Need to be able to adjust for a null $lastDt on the first run!
    */
    $cTime = $runDt->diff($lastDt);
    $cTime = $cTime->format('%d %H:%i:%s');
    $schOrMan;
    if ($runDt1 == "09:00:00"){
        $schOrMan = 'Morning';  // Used for automated morning runs
    } elseif ($runDt1 == "13:00:00") {
        $schOrMan = 'Afternoon';    // Uses for automated afternoon runs
    } else {
        $schOrMan = 'Manual';   // If it's one one of the two it has to be a manual run.
    }
    /******** End Time Determination ********/
    
    /******** Get Information From The Database ********
        * Will first get the IDs of all orders made since the last time the function
        * was executed. These will go into an array used to cycle through all order.
        * Next it will get all the data for all orders made since the last function
        * execution. This will organize the data in ascending order by lead_id (order
        * submission number) and then by field_number in ascending order. The latter
        * ordering ensures that fields with numbers which do not match with their 
        * position on form are placed in proper order for transfer to the EDP file.
    ********/
    /*
     * Fetch all orders between the last cron job and the current cron job. Each
     * order becomes an array point.
    */
    $sqlRes1 = $wpdb->prepare("SELECT id FROM `wp_j63diz_rg_lead` WHERE (`date_created` BETWEEN SUBTIME('$runDt1', '$cTime') AND '$runDt1') AND `form_id` = %d",5);
    $result1 = $wpdb->get_col($sqlRes1);
    // Store rows used in foreach loop
    $orders = array();
    foreach($result1 as $val){
        $orders[] = $val;
    }
    // print_r($orders);exit;
    /* 
     * Fetch data for each order in the current order set. Set the values into a 2D 
     * array. These values are ordered by Lead ID and then Field Number. This allows 
     * the primary code to run straight through each order and have all fields in 
     * the proper order.
     *
     * Note: empty optional fields do not get entered into the database. Prevents
     * empty data points from cluttering the table.
    */
    $sqlRes2 = $wpdb->prepare("SELECT `lead_id`,`field_number`,`value` FROM `wp_j63diz_rg_lead_detail` WHERE `form_id` = %d AND `lead_id` IN (SELECT `id` FROM `wp_j63diz_rg_lead` WHERE (`date_created` BETWEEN SUBTIME('$runDt1', '$cTime') AND '$runDt1' ) AND `form_id` = %d) ORDER BY `lead_id` ASC,`field_number` ASC",5,5);
    $results2 = $wpdb->get_results($sqlRes2);
    /******** End Get Information From The Database ********/
    
    /******** Data Point Labels For The EDP ********
        * The following variables are either fixed and used as lables on the EDP
        * document or need a lifespand longer than a single order loop.
    ********/
    // Unique Fields up through Shipping and including Notes
    $orderIDLabel = array("ExtOrder: ","date_External: ","Id_OrderType: ");
    $shippingLabel = array("ShipAddressCompany","ShipAddressCity: ","ShipAddressState: ","ShipAddressZip: ","ShipAddressCountry: ","ShipMethod: ");
    // Customer Fields - Pulled into the form from user information
    $customerLabel = array("id_Customer: ","Company: ");
    // Design and Location Arrays and variables
    $designLabel = array("ExtDesignID: ","id_DesignType: ","DesignName");
    $locationLabel = array("Location: ","ColorsTotal: ","FlashesTotal: ","Color: ");
    // Product Array are fixed and used for each product.
    $productLabel = array("PartNumber: ","PartDescription: ","PartColor: ","Size01_Req: ","Size02_Req: ","Size03_Req: ","Size04_Req: ","Size05_Req: ","Size06_Req: ","OrderInstructions: ");
    // Create bulk EDP as a .txt file
    $fileTime = str_replace (":", "-", $runDt1);     // Removes file unfriendly colons with file friendly dashes
    $filename = "orders-for-" . date("Y-m-d") . "-" . $fileTime; 
    $bulkEDP = fopen($filename. ".txt", "w");
    $txt;
    $edpPdf;
    //Assumes there are no orders when function is run.
    $numOrders = 0;
    /******** End Data Point Lables For The EDP ********/
    
    
    // Test for any orders then loop through the orders and fields
    $rowCount = $wpdb->num_rows; // Get the number of rows for the next if statement.
    if ($rowCount > 0) {
        /******** Primary function loop ********
            * Loop for adding all data to the EDP text file. It will generate 
            * a bulk style EDP file. By looping through each order and 
            * appending each new line of data in the EDP format to the text
            * file. It will continue with its loops until all orders appear in
            * the bulk EDP format on the text file.
        ********/
        foreach ($orders as $order) {
            $numOrders++;   // Increment number of orders by one
            /******** Variables with a lifespan of one Order loop ********
                * The following variables will exist only within the current
                * order loop.
            ********/
            // Increment variable used for counting through arrays
            $i = 0;
            // Shipping variables
            $trackEmail;
            $shipMethod;
            $shipAccount;
            // Design arrays and variables
            $designInfo1 = array();
            $designcolors1 = array();
            $designInfo2 = array();
            $designcolors2 = array();
            $designInfo3 = array();
            $designcolors3 = array();
            $designInfo4 = array();
            $designcolors4 = array();
            $numDesigns ;
            $lastDesignRow;
            // Services variables
            $digitize;
            $logoVctr;
            $foldNBag;
            $handTag;
            $tagPrnt;
            $stockNum;
            $custNum;
            $smallName;
            $fullSizeName;
            $cliProVinApp;
            $specServ = false;
            $specServSub = false;
            $heatPres = false;
            // Note boolean
            $noteProdShip = false;
            /******** End Variables with a lifespan of one Order loop ********/
            
            // Setup order Section
            $txt = "\"\r\r---- Start Order ----\r\r".PHP_EOL.PHP_EOL;
            fwrite($bulkEDP, $txt);
            /******** Order Loop ********
                * Runs until every row relevant to a single order recorded in the
                * lead_details table is turned into a single EDP Order Block. The 
                * loop will terminate when the lead_id no longer matches $order.
                *
                * To do so the function must loop through each row matched to the
                * current order in the for loop. Required information from each
                * row will be pulled from the value column.
            ********/
            // Start Order Block
            foreach ($results2 as $value) {
                if($value->lead_id == $order){
                     if ($value->field_number <= 3) {    // The first two items for this loop are hidden fields the clients do not see
                    if ($value->field_number != 3) {    // For Order ID and Order Date
                        $txt = $orderIDLabel[$i] . $value->value .PHP_EOL;
                        fwrite($bulkEDP, $txt);
                        $i++;
                    } else {    // the Order Type
                        $txt = $orderIDLabel[$i] . $value->value .PHP_EOL;
                        fwrite($bulkEDP, $txt);
                        $i = 0; // Reset increment for later use.
                    }
                }
                // Details SubBlock 
                elseif ($value->field_number == 4) {   // Records the customer in house purchase order ID
                    $txt = PHP_EOL.PHP_EOL."CustomerPurchaseOrder: " . $value->value .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                }
                // Dates SubBlock
                elseif ($value->field_number == 5) {    // Order Date - hidden field
                    $txt = PHP_EOL.PHP_EOL."date_OrderPlaced: " . $value->value .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                } elseif ($value->field_number == 6) {  // Ship By Date - optional
                    $txt = "date_OrderRequestedToShip: " . $value->value .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                } elseif ($value->field_number == 7) {    // Arrive By Date - optional
                    $txt = "date_OrderDropDead: " . $value->value .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                } 
                // Confirmation and Tracking email - Used in the notes section
                elseif ($value->field_number == 8) {
                    $trackEmail = $value->value;
                }
                // Shipping Subblock
                elseif ($value->field_number == 9) {    // Company
                    $txt = PHP_EOL. $shippingLabel[$i] . $value->value;
                    fwrite($bulkEDP, $txt);
                    $i++;
                } elseif ($value->field_number >= 10.1 && $value->field_number <= 10.6) {   // Shipping Address is comprized of multiple fields which each get a row.
                    if ($value->field_number == 10.1) {     // First address field is used for full street address
                        $txt =  "Address1: " . $value->value .PHP_EOL;
                        fwrite($bulkEDP, $txt);
                    } elseif ($value->field_number == 10.2) {   // Second address field is used as an "Attention To" line
                    $txt = "Address2: " . $value->value .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                    } else {    // Loops through city, state, and ZIP code.
                        $txt = $shippingLabel[$i] . $value->value .PHP_EOL;
                        fwrite($bulkEDP, $txt);
                        $i++;
                    }
                } elseif ($value->field_number == 11) {     // Shipping Method
                    $shipMethod = $value->value;    // Used later in the Notes.
                    $txt = $shippingLabel[$i] . $value->value .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                    $i = 0;     // End of EDP used shipping content, reset increment.
                } 
                // Shipping Account Number - used in notes section only
                elseif ($value->field_number ==12) {
                    $shipAccount = $value->value;
                }
                // Design Block - Contents of design block to be placed in Notes SubBlock
                elseif ($value->field_number == 13) {
                    /* 
                     * Checks the number of designs. Used to determin how many 
                     * fields before design content ends. The equation for the 
                     * ending field is:
                     * X designs * 6 fields per design + 17 previous fields - 1 field (to get actual field) = Ending field number
                     * Doing it this way prevents the design loop from trying 
                     * to look for fields that don't exist in the database.
                    */
                    $numDesigns = $value->value;
                    $lastDesignRow = $numDesigns * 6 + 17 - 1;
                }
                // Special Services: NOT PART OF THE DESIGN BLOCK!!! These all go down in the notes
                elseif ($value->field_number > 14 && $value->field_number < 15) {   // Extra Services
                    if ($value->field_number == 14.1) {
                        $digitize = $value->value . "<cr>";
                        $specServSub = true;
                    } elseif ($value->field_number == 14.2) {
                        $logoVctr = $value->value . "<cr>";
                        $specServ = true;
                    } elseif ($value->field_number == 14.3) {
                        $foldNBag = $value->value . "<cr>";
                        $specServ = true;
                    } elseif ($value->field_number == 14.4) {
                        $handTag = $value->value . "<cr>";
                        $specServ = true;
                    } else {
                        $tagPrnt = $value->value . "<cr>";
                        $specServSub = true;
                    }
                } elseif ($value->field_number > 15 && $value->field_number < 16) { // Heat Press Services
                    if ($value->field_number == 15.1) {
                        $stockNum = $value->value . "<cr>";
                        $heatPres = true;
                    } elseif ($value->field_number == 15.2) {
                        $custNum = $value->value . "<cr>";
                        $heatPres = true;
                    } elseif ($value->field_number == 15.3) {
                        $smallName = $value->value . "<cr>";
                        $heatPres = true;
                    } elseif ($value->field_number == 15.4) {
                        $fullSizeName = $value->value . "<cr>";
                        $heatPres = true;
                    } else {
                        $cliProVinApp;
                        $heatPres = true;
                    }
                } elseif ($value->field_number == 16) {
                    $txt = "";
                    fwrite($bulkEDP, $txt);
                }
                /*
                 * Design SubBlock info redirected to NotesToPurchasingSub 
                 * notes section by client request. Following if statement 
                 * groups can proably be condensed using a single function
                 * for each group. Maximum of four designs so statements 
                 * for a single field are in clusters of four.
                */
                elseif ($value->field_number >= 17 && $value->field_number <= ($lastDesignRow)) {
                    // Store design type field data
                    if ($value->field_number == 17 || $value->field_number == 23 || $value->field_number == 29 || $value->field_number == 35) {
                        if ($value->field_number == 17) {
                            array_push($designInfo1, $value->value);
                        } elseif ($value->field_number == 23) {
                            array_push($designInfo2, $value->value);
                        } elseif ($value->field_number == 29) {
                            array_push($designInfo3, $value->value);
                        } else {
                            array_push($designInfo4, $value->value);
                        }
                    }
                    // Store design size field data
                    elseif ($value->field_number == 18 || $value->field_number == 24 || $value->field_number == 30 || $value->field_number == 36) {
                        if ($value->field_number == 18) {
                            array_push($designInfo1, $value->value);
                        } elseif ($value->field_number == 24) {
                            array_push($designInfo2, $value->value);
                        } elseif ($value->field_number == 30) {
                            array_push($designInfo3, $value->value);
                        } else {
                            array_push($designInfo4, $value->value);
                        }
                    }
                    // Store a single design location per design
                    elseif ($value->field_number == 19 || $value->field_number == 25 || $value->field_number == 31 || $value->field_number == 37) {
                        if ($value->field_number == 19) {
                            array_push($designInfo1, $value->value);
                        } elseif ($value->field_number == 25) {
                            array_push($designInfo2, $value->value);
                        } elseif ($value->field_number == 31) {
                            array_push($designInfo3, $value->value);
                        } else {
                            array_push($designInfo4, $value->value);
                        }
                    }
                    // Store the number of colors per design
                    elseif ($value->field_number == 20 || $value->field_number == 26 || $value->field_number == 32 || $value->field_number == 37) {
                        if ($value->field_number == 20) {
                            array_push($designInfo1, $value->value);
                        } elseif ($value->field_number == 26) {
                            array_push($designInfo2, $value->value);
                        } elseif ($value->field_number == 32) {
                            array_push($designInfo3, $value->value);
                        } else {
                            array_push($designInfo4, $value->value);
                        }
                    }
                    // Store if a design has a flash or not. 
                    elseif ($value->field_number == 21 || $value->field_number == 27 || $value->field_number == 33 || $value->field_number == 39) {
                        if ($value->field_number == 21) {
                            array_push($designInfo1, $value->value);
                        } elseif ($value->field_number == 27) {
                            array_push($designInfo2, $value->value);
                        } elseif ($value->field_number == 33) {
                            array_push($designInfo3, $value->value);
                        } else {
                            array_push($designInfo4, $value->value);
                        }
                    }
                    // Store the serialized array of colors for each of up to four designs
                    elseif ($value->field_number == 22 || $value->field_number == 28 || $value->field_number == 34 || $value->field_number == 40) {
                        if ($value->field_number == 22) {
                            array_push($designInfo1, $value->value);
                        } elseif ($value->field_number == 29) {
                            array_push($designInfo2, $value->value);
                        } elseif ($value->field_number == 36) {
                            array_push($designInfo3, $value->value);
                        } else {
                            array_push($designInfo4, $value->value);
                        }
                    }
                }
                // Notes SubBlock
                elseif ($value->field_number == 41) {
                    //Set variables 
                    $specialServe;
                    $heatPressServe;
                    if ($specServ == true) {
                        $specialServe = "Extra Services:" . "<cr>" . $foldNBag . $handTag . "<cr>";
                    }
                    if ($heatPress == true) {
                        $heatPressServe = "Vinyl:" . "<cr>" . $stockNum . $custNum . $smallName . $fullSizeName . $cliProVinApp . "<cr>";
                    }
                    // Save notes to document
                    $txt = PHP_EOL.PHP_EOL."NotesToProduction: " . "Shipping Method = " . $shipMethod . "<cr>" . "Shipper Account = " . $shipAccount . "<cr>" . "Confirmation & Tracking Email: ". $trackEmail . "<cr><cr>" . $specialServe . $heatPressServe . $row["value"] . "\r" . "NotesToShipping: " . "Shipping Method = " . $shipMethod . "<cr>" . "Shipper Account = " . $shipAccount . "Confirmation & Tracking Email: ". $trackEmail . "<cr><cr>" . $specialServe . $heatPressServe . str_replace("\r", "<cr>", $value->value) .PHP_EOL; // String replaced used to remove carriage returns from paragraph fields
                    fwrite($bulkEDP, $txt);
                    $noteProdShip = true; // Prevents a later if statement will not trigger and add redundant text.
                } elseif ($value->field_number == 42) {
                    $txt = "NotesToReceiving: " . str_replace("\r", "<cr>", $value->value) .PHP_EOL; // String replaced used to remove carriage returns from paragraph fields
                    fwrite($bulkEDP, $txt);
                }
                // Customer Block
                elseif ($value->field_number == 43) {
                    /*
                     * If the client entered no notes then the plugin will add notes
                     * based off their other selections and provided information. 
                     * This is under 43 instead of 41 or 42 because if the optional 
                     * note fields are left blank then it wouldn't get added to the 
                     * database. The database field_number values have the potential 
                     * to skip everything between 22 and 43.
                     *
                     * The first secion ensures any selected extra options are passed 
                     * to production and shipping notes if they have been added.
                    */
                    $specialServe = "";
                    $heatPressServe = "";
                    if ($specServ == true) {    // Special Services only
                        $specialServe = "<cr><cr>Extra Services:<cr>" . $foldNBag . $handTag . "<cr>";
                    }
                    if ($heatPress == true) {   // Heat Press Services only
                        $heatPressServe = "<cr><cr>Vinyl:<cr>" . $stockNum . $custNum . $smallName . $fullSizeName . $cliProVinApp . "<cr>";
                    }
                    if ($noteProdShip == false) {   // Only triggers if there are no notes to production and shipping entered.
                        $txt = "NotesToProduction: Shipping Method = " . $shipMethod . "<cr>Shipper Account = " . $shipAccount . $specialServe . $heatPressServe . "\r" . "NotesToShipping: Shipping Method = " . $shipMethod . "<cr>Shipper Account = " . $shipAccount .$specialServe . $heatPressServe . "\r";
                        fwrite($bulkEDP, $txt);
                    }
                    /*
                     * Ensure any extra options are passed to the note section 
                     * selected to hold design information.
                    */
                    $specialServe = "";
                    $heatPressServ = "";
                    if ($specServ == true || $specServSub == true) {
                        $specialServe = "Extra Services:<cr>" . $digitize . $logVctr . $foldNBag . $handTag . $tagPrnt .  "<cr>";
                    }
                    if ($heatPress == true) {
                        $heatPressServe = "Vinyl:<cr>" . $stockNum . $custNum . $smallName . $fullSizeName . $cliProVinApp . "<cr>";
                    }
                    // Design information to go into Notes to Subcontract Purchasing.
                    $i = 1;     // Number of colors has a minimum value of one.
                    $designData = "<cr><cr>Design Type: " . $designInfo1[0] . "<cr>Dimensions: " . $designInfo1[1] . "<cr>Location: " . $designInfo1[2] . "<cr>Number of Colors: " . $designInfo1[3] . "<cr>Number of Flashes: " . $designInfo1[4];
                    while ($i <= $designInfo1[3]) {     // Get the colors in the design
                        $designData .= "<cr>Color: " . $designColors1[$i - 1];  // Array starts at 0 so i must be converted to proper position
                        $i++;
                    }
                    $i = 1;
                    if ($numDesigns >= 2) {
                        $designData .= "<cr><cr>Design 2<cr><cr>Design Type: " . $designInfo2[0] . "<cr>Dimensions: " . $designInfo2[1] . "<cr>Location: " . $designInfo2[2] . "<cr>Number of Colors: " . $designInfo2[3] . "<cr>Number of Flashes: " . $designInfo2[4];
                        while ($i <= $designInfo2[3]) {
                            $designData .= "<cr>Color: " . $designColors2[$i - 1];
                            $i++;
                        }
                        $i = 1;
                        if ($numDesigns >= 3) {
                            $designData .= "<cr><cr>Design 3<cr>Design Type: " . $designInfo3[0] . "<cr>Dimensions: " . $designInfo3[1] . "<cr>Location: " . $designInfo3[2] . "<cr>Number of Colors: " . $designInfo3[3] . "<cr>Number of Flashes: " . $designInfo3[4];
                            while ($i <= $designInfo3[3]) {
                                $designData .= "<cr>Color: " . $designColors3[$i - 1];
                                $i++;
                            }
                            $i = 1;
                            if ($numDesigns == 4) {
                                $designData .= "<cr><cr>Design 4<cr>Design Type: " . $designInfo4[0] . "<cr>Dimensions: " . $designInfo4[1] . "<cr>Location: " . $designInfo4[2] . "<cr>Number of Colors: " . $designInfo4[3] . "<cr>Number of Flashes: " . $designInfo4[4];
                                while ($i <= $designInfo4[3]) {
                                    $designData .= "<cr>Color: " . $designColors4[$i - 1];
                                    $i++;
                                }
                            }
                        }
                    }
                    $txt = PHP_EOL.PHP_EOL."NotesToPurchasingSub: " . $specialServe . $heatPressServe . "<cr>Designs<cr><cr>Design 1" . $designData . "\r\r" . "---- End Order ----" ."\r\r";
                    fwrite($bulkEDP, $txt);
                    // Actual Start of Customer Block
                    $txt = PHP_EOL.PHP_EOL."---- Start Customer ----" .PHP_EOL 
                    .PHP_EOL. "id_Customer" . $value->value 
                    .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                } elseif ($value->field_number == 44) {
                    $txt = "Company: " . $value->value . "\r\r" . "---- End Customer ----" .PHP_EOL;
                    fwrite($bulkEDP, $txt);
                }
                /******** Product Block ********
                    * Products are stored as serialized 3D array
                    ********/
                elseif ($value->field_number == 45) {
                    $productData = array();
                    $productData = unserialize($value->value);  // Converts a serialized array into a two dimentional array
                    $prodArray = count($productData) - 1;   // Reduces count to account for the 0th array point.
                    $txt = PHP_EOL."---- Start Product ----" . "\r\r";
                    fwrite($bulkEDP, $txt);
                    for ($i = 0; $i <= $prodArray; $i++) {  // loops through each product and grabs all relevant data
                        $txt = PHP_EOL.PHP_EOL."PartNumber: " . $productData[$i]['Product ID'] 
                        . PHP_EOL . "PartDescription: " . $productData[$i]['Product Description'] 
                        . PHP_EOL . "PartColor: " . $productData[$i]['Product Color'] 
                        . PHP_EOL . "Size01_Req: " . $productData[$i]['S'] 
                        . PHP_EOL . "Size02_Req: " . $productData[$i]['M'] 
                        . PHP_EOL . "Size03_Req: " . $productData[$i]['L'] 
                        . PHP_EOL . "Size04_Req: " . $productData[$i]['XL'] 
                        . PHP_EOL . "Size05_Req: " . $productData[$i]['O/S'] 
                        . PHP_EOL . "Size06_Req: " . $productData[$i]['Other']
                        . PHP_EOL . "OrderInstructions: " . $productData[$i]['Order Instructions'] 
                        . "\r\r" .PHP_EOL.PHP_EOL."---- End Product ----" .PHP_EOL;
                        fwrite($bulkEDP, $txt);
                        if ($i < $prodArray) {  // Start new product section if i is less than the array count.
                            $txt = PHP_EOL."---- Start Product ----" .PHP_EOL;
                            fwrite($bulkEDP, $txt);
                        } else {
                            $txt = "\"\r";
                            fwrite($bulkEDP, $txt);
                        }
                    }
                }
            }
        }
    }
        /******** Create/Send Email with EDP PDF attachement ********
            * Need to create a PDF, create the email with PDF attachment, send the 
            * email, and update the CRON job table in the DB.
            * 
            * MISSING: Create PDF file for export via email and email creating and
            * sending.
          ********/
        // log time of job run
          // $compTime = current_time(mysql);
        $compTime = 1;
        $currentTime = date('Y-m-d H:i:s');
        $wpdb->insert( $cron_log_table, array("datetime_run" => $currentTime, "run_complete" => $compTime, "run_type" => $schOrMan, "num_orders" => $numOrders) );
        $text = file_get_contents($filename . ".txt");
        ob_start();
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Times');
        $pdf->Write(5,$text);
        $pdf->SetLeftMargin(15);
        $pdf->Output($filename.".pdf",'f');
        $admin_directory = ABSPATH.'/wp-admin/';
        $attachements = array($admin_directory.$filename.".pdf");
    $to = 'creative@ctg-reno.com';      // Receiver
    $subject = $numOrders . ' Web Portal Orders made between ';      // Subject Line - !!!NOT COMPLETE!!! Need to add dates orders were made
    $body = 'Greetings Stitches Clothing Co.,' . "\r" . 'You have recieved ' . $numOrders . ' orders from the web portal since the last batch was sent.' . "\r" . 'Have a nice day' . "\r" . 'Stitches Orderbot';    // Body content
    $headers = array('Content-Type: text/html; charset=UTF-8');   // Header info
    
    wp_mail($to, $subject, $body,$headers,$attachements);
    success_popup('Success',$numOrders);
} else {
        /******** Create/Email notifying of no orders. ********
            * Create and send email notifying no orders have been made through the
            * portal. Update the CRON job table in the DB.
            *
            * MISSING: Creation email creation and sending message.
          ********/
          // $compTime = current_time(mysql);
        $compTime = 0;
        $currentTime = date('Y-m-d H:i:s');
        $wpdb->insert( $cron_log_table, array("datetime_run" => $currentTime, "run_complete" => $compTime, "run_type" => $schOrMan, "num_orders" => $numOrders) );
        success_popup('Failed',$numOrders);
    }
    
    return;
}
// All hail Stitches Orderbot
?>